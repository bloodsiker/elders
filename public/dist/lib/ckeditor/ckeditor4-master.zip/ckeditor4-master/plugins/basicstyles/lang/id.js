/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'id', {
	bold: 'Huruf Tebal',
	italic: 'Huruf Miring',
	strike: 'Strikethrough', // MISSING
	subscript: 'Subscript', // MISSING
	superscript: 'Superscript', // MISSING
	underline: 'Garis Bawah'
} );
