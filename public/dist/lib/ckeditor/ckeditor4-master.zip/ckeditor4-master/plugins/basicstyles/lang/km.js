/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'km', {
	bold: 'ដិត',
	italic: 'ទ្រេត',
	strike: 'គូស​បន្ទាត់​ចំ​កណ្ដាល',
	subscript: 'អក្សរតូចក្រោម',
	superscript: 'អក្សរតូចលើ',
	underline: 'គូស​បន្ទាត់​ក្រោម'
} );
