/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'bg', {
	bold: 'Удебелен',
	italic: 'Наклонен',
	strike: 'Зачертан текст',
	subscript: 'Долен индекс',
	superscript: 'Горен индекс',
	underline: 'Подчертан'
} );
