/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'ko', {
	bold: '굵게',
	italic: '기울임꼴',
	strike: '취소선',
	subscript: '아래 첨자',
	superscript: '위 첨자',
	underline: '밑줄'
} );
