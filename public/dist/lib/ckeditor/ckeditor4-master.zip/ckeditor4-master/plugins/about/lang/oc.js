/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'oc', {
	copy: 'Copyright &copy; $1. Totes los dreits reservats.',
	dlgTitle: 'A prepaus de CKEditor 4',
	moreInfo: 'Per las informacions de licéncia, visitatz nòstre site web :'
} );
