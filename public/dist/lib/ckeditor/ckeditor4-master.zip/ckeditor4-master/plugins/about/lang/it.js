/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'it', {
	copy: 'Copyright &copy; $1. Tutti i diritti riservati.',
	dlgTitle: 'Informazioni su CKEditor 4',
	moreInfo: 'Per le informazioni sulla licenza si prega di visitare il nostro sito:'
} );
