/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'pl', {
	copy: 'Copyright &copy; $1. Wszelkie prawa zastrzeżone.',
	dlgTitle: 'Informacje o programie CKEditor 4',
	moreInfo: 'Informacje na temat licencji można znaleźć na naszej stronie:'
} );
