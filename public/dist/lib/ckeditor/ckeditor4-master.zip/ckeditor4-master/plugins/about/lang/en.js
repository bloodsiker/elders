/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'en', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: 'About CKEditor 4',
	moreInfo: 'For licensing information please visit our web site:'
} );
