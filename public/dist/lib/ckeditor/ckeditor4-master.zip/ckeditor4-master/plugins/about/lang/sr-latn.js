/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'sr-latn', {
	copy: 'Copyright &copy; $1. Sva prava zadržana.',
	dlgTitle: 'O CKEditor 4',
	moreInfo: 'Za informacije o licenci posetite našu web stranicu:'
} );
