/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'eo', {
	copy: 'Copyright &copy; $1. Ĉiuj rajtoj rezervitaj.',
	dlgTitle: 'Pri CKEditor 4',
	moreInfo: 'Por informoj pri licenco, bonvolu viziti nian retpaĝaron:'
} );
