/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'ru', {
	copy: 'Copyright &copy; $1. Все права защищены.',
	dlgTitle: 'О CKEditor 4',
	moreInfo: 'Для получения информации о лицензии, пожалуйста, перейдите на наш сайт:'
} );
