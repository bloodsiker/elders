/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'sk', {
	copy: 'Copyright &copy; $1. Všetky práva vyhradené.',
	dlgTitle: 'O aplikácii CKEditor 4',
	moreInfo: 'Pre informácie o licenciách, prosíme, navštívte našu web stránku:'
} );
