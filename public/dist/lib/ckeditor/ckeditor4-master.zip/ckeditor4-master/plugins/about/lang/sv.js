/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'sv', {
	copy: 'Copyright &copy; $1. Alla rättigheter reserverade.',
	dlgTitle: 'Om CKEditor 4',
	moreInfo: 'För information om licensiering besök vår hemsida:'
} );
