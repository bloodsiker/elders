/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'gl', {
	copy: 'Copyright &copy; $1. Todos os dereitos reservados.',
	dlgTitle: 'Sobre o CKEditor 4',
	moreInfo: 'Para obter  información sobre a licenza, visite o noso sitio web:'
} );
