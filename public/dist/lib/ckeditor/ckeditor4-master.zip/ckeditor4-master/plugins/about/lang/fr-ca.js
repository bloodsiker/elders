/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'fr-ca', {
	copy: 'Copyright &copy; $1. Tous droits réservés.',
	dlgTitle: 'À propos de CKEditor 4',
	moreInfo: 'Pour les informations de licence, consulter notre site internet:'
} );
