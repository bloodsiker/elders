/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'ar', {
	copy: 'حقوق النشر &copy; $1. جميع الحقوق محفوظة.',
	dlgTitle: 'عن CKEditor',
	moreInfo: 'للحصول على معلومات الترخيص ، يرجى زيارة موقعنا:'
} );
