/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'ug', {
	copy: 'Copyright &copy; $1. نەشر ھوقۇقىغا ئىگە',
	dlgTitle: 'CKEditor تەھرىرلىگۈچى 4 ھەقىدە',
	moreInfo: 'تور تۇرايىمىزنى زىيارەت قىلىپ كېلىشىمگە ئائىت تېخىمۇ كۆپ ئۇچۇرغا ئېرىشىڭ'
} );
