/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'no', {
	copy: 'Copyright &copy; $1. Alle rettigheter reservert.',
	dlgTitle: 'Om CKEditor 4',
	moreInfo: 'For lisensieringsinformasjon, vennligst besøk vårt nettsted:'
} );
