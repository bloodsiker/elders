/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'lv', {
	copy: 'Kopēšanas tiesības &copy; $1. Visas tiesības rezervētas.',
	dlgTitle: 'Par CKEditor 4',
	moreInfo: 'Informācijai par licenzēšanu apmeklējiet mūsu mājas lapu:'
} );
