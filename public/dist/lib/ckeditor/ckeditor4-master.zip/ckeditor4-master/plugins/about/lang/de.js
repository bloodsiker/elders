/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'de', {
	copy: 'Copyright &copy; $1. Alle Rechte vorbehalten.',
	dlgTitle: 'Über CKEditor 4',
	moreInfo: 'Für Informationen über unsere Lizenzbestimmungen besuchen sie bitte unsere Webseite:'
} );
