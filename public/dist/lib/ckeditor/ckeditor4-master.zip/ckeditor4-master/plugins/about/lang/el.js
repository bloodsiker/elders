/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'el', {
	copy: 'Πνευματικά δικαιώματα &copy; $1 Με επιφύλαξη παντός δικαιώματος.',
	dlgTitle: 'Περί του CKEditor 4',
	moreInfo: 'Για πληροφορίες σχετικές με την άδεια χρήσης, παρακαλούμε επισκεφθείτε την ιστοσελίδα μας:'
} );
