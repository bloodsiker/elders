/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'fa', {
	copy: 'حق نشر &copy; $1. کلیه حقوق محفوظ است.',
	dlgTitle: 'درباره CKEditor',
	moreInfo: 'برای کسب اطلاعات مجوز لطفا به وب سایت ما مراجعه کنید:'
} );
