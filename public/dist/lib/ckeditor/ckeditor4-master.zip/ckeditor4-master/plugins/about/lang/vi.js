/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'vi', {
	copy: 'Bản quyền &copy; $1. Giữ toàn quyền.',
	dlgTitle: 'Thông tin về CKEditor 4',
	moreInfo: 'Vui lòng ghé thăm trang web của chúng tôi để có thông tin về giấy phép:'
} );
