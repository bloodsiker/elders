/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'zh-cn', {
	copy: '版权所有 &copy; $1。<br />保留所有权利。',
	dlgTitle: '关于 CKEditor 4',
	moreInfo: '相关授权许可信息请访问我们的网站：'
} );
