/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'about', 'ko', {
	copy: '저작권 &copy; $1 . 판권 소유.',
	dlgTitle: 'CKEditor 에 대하여',
	moreInfo: '라이선스에 대한 정보는 저희 웹 사이트를 참고하세요:'
} );
