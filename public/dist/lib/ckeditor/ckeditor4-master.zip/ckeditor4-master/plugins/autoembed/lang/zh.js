/*
 Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
 */
CKEDITOR.plugins.setLang( 'autoembed', 'zh', {
	embeddingInProgress: '正在嘗試嵌入已貼上的 URL...',
	embeddingFailed: '這個 URL 無法被自動嵌入。'
} );
