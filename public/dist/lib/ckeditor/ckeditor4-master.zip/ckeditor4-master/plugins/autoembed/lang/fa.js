/*
 Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
 */
CKEDITOR.plugins.setLang( 'autoembed', 'fa', {
	embeddingInProgress: 'در حال تلاش برای جایگذاری آدرس قرارگرفته',
	embeddingFailed: 'این آدرس نمیتواند به صورت خودکار جایگذاری شود'
} );
