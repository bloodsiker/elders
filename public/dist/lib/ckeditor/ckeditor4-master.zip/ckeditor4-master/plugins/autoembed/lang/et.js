/*
 Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
 */
CKEDITOR.plugins.setLang( 'autoembed', 'et', {
	embeddingInProgress: 'Püütakse asetatud URLi sisu lisada...',
	embeddingFailed: 'Selle URLi sisu ei saa automaatselt dokumenti lisada.'
} );
