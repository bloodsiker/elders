/*
 Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
 */
CKEDITOR.plugins.setLang( 'autoembed', 'de-ch', {
	embeddingInProgress: 'Einbetten der eingefügten URL wird versucht...',
	embeddingFailed: 'Diese URL konnte nicht automatisch eingebettet werden.'
} );
